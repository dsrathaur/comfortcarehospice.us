<?php

// do some basic checks for strings
class Escape_Home_URL_Checks implements themecheck {
	protected $error = array();

	function check( $php_files, $css_files, $other_files) {

		$php = implode( ' ', $php_files );
		$grep = '';
		$ret = true;

		$checks = array(
			'echo\s?home\_url\(' => __( ' Use instead:', 'theme-check' ) . " <b>echo esc_url( home_url( '/' ) );</b>",
			);

		foreach ( $php_files as $php_key => $phpfile ) {
			foreach ($checks as $key => $check) {
				checkcount();

				if ( false !== preg_match_all( '/' . $key . '/', $phpfile, $matches ) ) {
					foreach ($matches[0] as $match) {
						$error = ltrim($match, '(');
						$error = rtrim($error, '(');
						$grep = tc_grep($error, $php_key);
						$this->error[] = sprintf(
							'<span class="tc-lead tc-warning">' . __('WARNING', 'theme-check') . '</span>: ' . __('Invalid usage %1$s was found in the file %2$s.%3$s', 'theme-check'),
							'<strong>' . $match . '</strong>',
							'<strong>' . $php_key . '</strong>',
							$check,
							$grep
						);
						$ret = false;
					}
				}
			}
		}

		return $ret;
	}

	function getError() { return $this->error; }
}

$themechecks[] = new Escape_Home_URL_Checks;
