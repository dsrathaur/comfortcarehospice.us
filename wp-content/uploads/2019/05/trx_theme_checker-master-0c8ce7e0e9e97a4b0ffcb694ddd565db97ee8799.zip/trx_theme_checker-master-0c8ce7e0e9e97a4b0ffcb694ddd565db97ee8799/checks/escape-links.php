<?php

// do some basic checks for strings
class Escape_Links implements themecheck {
	protected $error = array();

	function check( $php_files, $css_files, $other_files) {

		$php = implode( ' ', $php_files );
		$grep = '';
		$ret = true;

		$checks = array(
			'href="\'\s*\.\s*[^e]{2}' => __( ' This link seems not to be escaped.', 'theme-check.' ),
			'href="<\?php\s*echo\s*[^e]{2}' => __( ' This link seems not to be escaped.', 'theme-check' ),
			);

		foreach ( $php_files as $php_key => $phpfile ) {
			foreach ($checks as $key => $check) {
				checkcount();

				if ( false !== preg_match_all( '/' . $key . '/', $phpfile, $matches ) ) {
					foreach ($matches[0] as $match) {
						$error = ltrim($match, '(');
						$error = rtrim($error, '(');
						$grep = tc_grep($error, $php_key);
						$this->error[] = sprintf(
							'<span class="tc-lead tc-warning">' . __('WARNING', 'theme-check') . '</span>: ' . __('Escape link. %1$s was found in the file %2$s.%3$s %4$s', 'theme-check'),
							'<span class="tc-grep"><span>' . htmlentities2($match) . '</span></span>',
							'<strong>' . $php_key . '</strong>',
							$check,
							$grep
						);
						$ret = false;
					}
				}
			}
		}

		return $ret;
	}

	function getError() { return $this->error; }
}

$themechecks[] = new Escape_Links;
