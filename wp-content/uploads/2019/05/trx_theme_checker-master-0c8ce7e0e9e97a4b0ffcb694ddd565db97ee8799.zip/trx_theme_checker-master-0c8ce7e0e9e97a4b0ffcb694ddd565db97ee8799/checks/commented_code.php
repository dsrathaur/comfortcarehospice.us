<?php
/**
 * This checks, if the admin bar gets hidden by the theme
 **/
class CommentedCode implements themecheck {
	protected $error = array();

	function check( $php_files, $css_files, $other_files ) {
		$ret = true;
		checkcount();
		$php_checks = array(
			'/\/\/\s*\$[\w\d_]+/i',
			'/\/[\*]{1,2}(\s)*\$\w+\s*/',
		);
		$css_regex = "/\/\*\s*\.[.\w\-_\s]+/";

		//Check php files for filter show_admin_bar and show_admin_bar()
		foreach ( $php_files as $file_path => $file_content ) {
			checkcount();

			$file_content = file_get_contents( $file_path );

			foreach ( $php_checks as $php_regex ) {
				if ( preg_match( $php_regex, $file_content, $matches ) ) {
					foreach ($matches as $match ) {
						$error = ltrim( $match, '(' );
						$error = rtrim( $error, '(' );
						$grep = tc_grep( $error, $file_path );
						$this->error[] = sprintf(' <br> - ' . __('%1$s was found in the file %2$s. %3$s', 'theme-check'),
							'<strong>' . $error. '</strong>',
							'<strong>' . $file_path . '</strong>',
							$grep );
					}

					$this->error[] = sprintf( '<span class="tc-lead tc-required">' . __( 'WARNING', 'theme-check').'</span>: ' . __( 'Maybe commented code found.', 'theme-check' ),
						'<strong>' . $file_path . '</strong>');
					$ret = false;
				}
			}
		}

		//Check CSS Files for #wpadminbar
		foreach ( $css_files as $file_path => $file_content ) {
			if ( preg_match( $css_regex, $file_content, $matches ) ) {
				foreach ($matches as $match ) {
					$error = ltrim( $match, '(' );
					$error = rtrim( $error, '(' );
					$grep = tc_grep( $error, $file_path );
					$this->error[] = sprintf('<span class="tc-lead tc-warning">'.__('WARNING','theme-check').'</span>: '.__('Maybe commented code found at %1$s. %2$s', 'theme-check'),
						'<strong>' . $file_path . '</strong>',
						$grep );
				}
			}
		}
		return $ret;
	}

	function getError() { return $this->error; }
}
$themechecks[] = new CommentedCode;
