<?php

define( 'REDIRECTION_VERSION', '4.7.1' );
define( 'REDIRECTION_BUILD', '757de0cd5e38c5123af1b6a54b74cc9a' );
define( 'REDIRECTION_MIN_WP', '4.6' );
